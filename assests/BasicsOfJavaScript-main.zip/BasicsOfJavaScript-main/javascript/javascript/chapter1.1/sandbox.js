// alert('hello, world');
// console.log(1);
// console.log(2);


// let age = 25;
// let year = 2022; 
// console.log(age, year);

// age = 30;
// console.log(age);

// constants
// const points = 100;
// console.log(points);

// variables
// var score =75;
// console.log(score);

// we can't use spaces for this reason we can use camel case
// let myAge = 23;
// console.log(myAge);


