//arguments & parameters

// const speak = function(name, time){
//     console.log(` good ${time} ${name}`);
// };

// speak();

//assigning default values

// const speak = function(name ='pekka', time ='wiz'){
//     console.log(` good ${time} ${name}`);
// };

// speak('vulk', 'night');
// speak('wiz', 'morning');

//returning values

const calcArea = function(radius){
    return 3.14 * radius**2;
    // let area = 3.14 * radius**2;
    // console.log(area);
    // return area;
}

const area = calcArea(5);
console.log(area)

const calcVol = function(area){

};
calcVol(area);
