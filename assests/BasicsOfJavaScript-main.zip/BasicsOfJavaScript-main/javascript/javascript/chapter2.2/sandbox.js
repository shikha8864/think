// if statements

// const age = 25;
// if(age>20){
//     console.log('print ages');
// }
// const troops = ['vulk', 'pekka', 'golem', 'prince'];
// if(troops.length > 4){
//     console.log('there are many troops');
// }

// const password = 'password';
// if(password.length >=8){
//     console.log('password');
// }

//else if statement

// const password = 'p@ssword12345';
// if(password.length >= 12){
//     console.log('strong password')
// }else if(password.length >= 8){
//     console.log('ok fine!');
// }else{
//     console.log('Not ok!');
// }

//logical operators - OR || and AND &&

// const password = 'p@ssword12345';
// if(password.length >= 12 && password.includes('@')){
//     console.log('strong password')
// }else if(password.length >= 8 || password.includes('@')){
//     console.log('ok fine!');
// }else{
//     console.log('Not ok!');
// }

//logical NOT - !

// let user = false;
// if(user){

// }
// if(!user){
//    console.log('login to continue');
// }
// console.log(!true);
// console.log(!false);


