//strings
// console.log('hello,world');

// let email = 'abc@learnJs';
// console.log(email);


// //string concatenation

let firstName = 'kEvin';
let lastName = 'OWeNs';
let fullName = firstName + ' ' + lastName;
console.log(fullName);

// getting characts
// console.log(fullName[2]);

//string length
// console.log(fullName.length);

//string methods
// console.log(fullName.toUpperCase());
// let result = fullName.toLowerCase();
// console.log(result);

// let index = email.indexOf('@');
// console.log(index);

//common string methods
let path = 'abc@learnJs';
// let resultPath = path.lastIndexOf('a');
// let resultPath = path.slice(0,5);
// let resultPath = path.substring(4,10);
let resultPath = path.replace('c', 'x');
console.log(resultPath);