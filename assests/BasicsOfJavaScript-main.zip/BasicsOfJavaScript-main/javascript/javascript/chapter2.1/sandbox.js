// //for loops

// for(let i=0; i<5; i++){
//     console.log('in loop:', i);
// }
// console.log('loop finished');

// const names = ['vulk', 'pekka', 'wiz'];

// for(let i=0; i<names.length; i++){
//     // console.log(names[i]);
//     let html = `<div>${names[i]}<div/>`;
//     console.log(html);
// }

// //while loops

// while(i<5){
//     console.log('in loop:', i);
//     i++;
// }
// const names = ['vulk', 'pekka', 'wiz'];
// let i = 0;
// while(i<names.length){
//     console.log(names);
//     i++;
// }

// //do while loops

// let i = 5;
// do{
//     console.log('val of i is', i);
//     i++;
// }while(i<5);