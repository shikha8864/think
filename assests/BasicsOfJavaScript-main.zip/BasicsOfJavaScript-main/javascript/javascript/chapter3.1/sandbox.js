//function declaration

function greet(){
    console.log('hello');
}

//function expression, calling the function & hoisting

const speak = function(){
    console.log('have a good day');
}


// greet();
// greet();
// greet();

speak();
speak();
speak();

// function greet(){
//     console.log('hello');
// }

// const speak = function(){
//     console.log('have a good day');
// }
