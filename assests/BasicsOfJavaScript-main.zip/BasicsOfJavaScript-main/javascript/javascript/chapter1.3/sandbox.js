let radius = 10;
const pi = 3.14;
// console.log(radius, pi);

// math operators =>: +, -, *, /, **, %

// console.log(10/2);
// let result = radius % 3;
// console.log(result);
// let result = pi* radius **2;
//order of operation - B O D M A S
// let result = 5 * (10-3)**2;
// console.log(result);


let like = 10;
// like = like + 1;
// like++;
// like--;
// like += 10;
// like -= 10;
// like *= 10;
// like /= 10;
// console.log(like);
//NaN - not a number
// console.log(5 / 'hello');
// console.log(5 * 'hello');
let result = 'the blog has ' + like + ' likes';
console.log(result);

