// let age = null;
// console.log(age, age +3, `the age is ${age}`);

// boolean & comparisons
// console.log(true, false, "true", "false");

//methods can return booleans
// let email = 'abc@gmail.com'
// let names = ['vulk', 'wiz', 'pekka']
// let result = email.includes('@');
// let result = email.includes('!');
// let result = names.includes('vulk');
// let result = names.includes('minion');
// console.log(result);

// comparison operators
// let age = 35;
// console.log(age == 25);
// console.log(age == 30);
// console.log(age!= 25);
// console.log(age > 20);
// console.log(age < 20);
// console.log(age <= 25);
// console.log(age >= 25);

// let name = 'vulk';
// console.log(name == 'vulk');
// console.log(name == 'wiz');
// console.log(name > 'pekka');
// console.log(name < 'hogrider');

