let royal = ['wiz', 'pekka', 'vulk'];
console.log(royal);
// console.log(royal);
// console.log(royal[0]);
// console.log(royal[1]);
// console.log(royal[2]);
// royal[1] = 'hogRider';
// console.log(royal[1]);

// let ages = [21, 22, 25, 23, 27];
// console.log(ages[3]);
// console.log(ages);
let clash = ['miniPekka', 'grandWarden', 25, 23];
// console.log(clash);
// console.log(clash[1]);
// console.log(clash[2]);
// console.log(clash.length);

//array methods

// let result = royal.join(',');
// let result = royal.join('-');

// let result = royal.indexOf('wiz');
// let result = royal.concat(['minion', 'golem']);
let result = royal.push('knight');
// let trigger = result.join(',');
console.log(result);
console.log(royal);

// console.log(trigger);
